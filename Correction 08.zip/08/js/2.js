/**
 * créer une boucle qui va itérer 10 fois.
 * A chaque itération afficher : " 1 * 9 = 9", "2 * 9 = 18", etc
 **/

function table_de_9() {
  for (let i = 1; i <= 9; i++) {
    console.log( i + " * 9 = " + i*9);
  }
}

function table_de_multiplication(x, nombre_iteration) {
  for (let i = 1; i <= nombre_iteration; i++) {
    console.log( i + " * " + x + " = " + i*x);
  }
}
table_de_multiplication(9, 5);
table_de_multiplication(12, 20);