/**
 *sondage ( demander un chiffre et afficher la moyenne de tous les chiffres demandés précédemment )
 */
function sondage() {
  // demander le nombre de notes
  const nombre_de_notes = prompt("Combien de notes voulez vous renseigner");

  // demander les notes
  const liste_des_notes = [];
  for (let i = 0; i < nombre_de_notes; i++) {
    // demander une note
    let note = prompt("Veuillez renseigner la note " + (i + 1));

    // convertir la note en number
    note = parseInt(note);

    // stocker la note dans un tableau
    liste_des_notes.push(note);
  }

  // calculer la moyenne des notes contenues dans le tableau
  let somme = 0;
  for (let j = 0; j < liste_des_notes.length; j++) {
    // récupérer la note à l'indice j dans le tableau des notes
    const note = liste_des_notes[j];
    // j'ajoute à somme, la valeur de la note de l'itération
    somme = somme + note;
  }

  console.log(" la somme est " + somme);
  console.log(" la moyenne est " + (somme / nombre_de_notes));
}

function sondage_bis() {
  const nombre_de_notes = prompt("Combien de notes voulez vous renseigner");

  let somme = 0;
  for (let i = 0; i < nombre_de_notes; i++) {
    // demander une note
    let note = prompt("Veuillez renseigner la note " + (i + 1));

    // on l'ajoute à la somme générale
    somme = somme + parseInt(note);
  }

  console.log(" la somme est " + somme);
  console.log(" la moyenne est " + (somme / nombre_de_notes));
}

function sondage_illimite() {

  let somme = 0;
  let nombre_de_notes = 0;
  let note = prompt("Veuillez renseigner la note ");

  while(note !== "") {
    // on l'ajoute à la somme générale
    somme = somme + parseInt(note);

    // j'enregistre une note de plus
    nombre_de_notes++;

    // demander une note
    note = prompt("Veuillez renseigner la note " + (nombre_de_notes+1));
  }

  console.log(" la somme est " + somme);
  console.log(" la moyenne est " + (somme / nombre_de_notes));
}
sondage_illimite();