/**
 * créer fonction qui calcule si un nombre est premier
 * ( un nombre est premier si il n'est pas divisible par un nombre plus petit )
 **/


function est_premier(x) {
  for (let i = 2; i < x; i++) {
    if (x % i === 0) {
      // alors le nombre x est divisible par i
      // donc il n'est pas premier
      return false;
    }
  }
  return true;
}

console.log("2 : " + est_premier(2));
console.log("3 : " + est_premier(3));
console.log("9999991 : " + est_premier(9999991));