/**
 * créer une boucle qui va itérer 20 fois.
 * A chaque itération, il faut afficher dans la console :
 * "le nombre X est pair", ou "le nombre X est impair"
 **/

function iteration_20() {
  for (let i = 0; i < 20; i++) {
    if (i % 2 === 0) {
      console.log("le nombre " + i + " est pair ");
    } else {
      console.log("le nombre " + i + " est impair ")
    }
  }
}

function iteration_20_bis() {
  for (let i = 0; i < 20; i++) {
    console.log("le nombre " + i + " est " + (i%2===0 ? 'pair' : 'impair'));
  }
}